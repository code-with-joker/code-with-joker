export type TargetUnit = 'KB' | 'MB';

const MAX_ITERATIONS = 15; // Increased iterations for better precision
const SIZE_TOLERANCE_PERCENT = 0.05; // Allow 5% tolerance
const MIN_QUALITY_STEP = 0.005; // Minimum quality change to avoid infinite loops in tight constraints

/**
 * Compresses an image to a target size.
 * @param imageFile The image file to compress.
 * @param targetSize The desired size (e.g., 500).
 * @param targetUnit The unit for the desired size ('KB' or 'MB').
 * @param outputFormat The desired output format (e.g., 'image/jpeg').
 * @returns A Promise that resolves to the compressed image Blob or null if compression fails.
 */
export async function compressImageToTargetSize(
  imageFile: File,
  targetSize: number,
  targetUnit: TargetUnit,
  outputFormat: 'image/jpeg' | 'image/webp' = 'image/jpeg'
): Promise<{ blob: Blob; quality: number } | null> {
  const targetBytes = targetUnit === 'MB' ? targetSize * 1024 * 1024 : targetSize * 1024;

  if (targetBytes <= 0) return null;
  
  // If original image is already smaller than target, and it's the target format, return it directly
  // Or if it's a PNG and target is small, it might be impossible without conversion
  if (imageFile.size <= targetBytes && imageFile.type === outputFormat) {
    return { blob: imageFile, quality: 1.0 };
  }

  let image: ImageBitmap;
  try {
    image = await createImageBitmap(imageFile);
  } catch (error) {
    console.error("Error creating ImageBitmap:", error);
    return null;
  }
  
  const canvas = document.createElement('canvas');
  canvas.width = image.width;
  canvas.height = image.height;
  const ctx = canvas.getContext('2d');

  if (!ctx) return null;

  // Fill background for transparent PNGs if converting to JPEG
  if (outputFormat === 'image/jpeg' && (imageFile.type === 'image/png' || imageFile.type === 'image/webp')) {
    ctx.fillStyle = '#FFFFFF'; // White background
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }
  ctx.drawImage(image, 0, 0);
  image.close(); // Release memory

  let quality = 0.85; // Initial quality guess
  let minQuality = 0.01; // JPEG quality minimum is very low, effectively
  let maxQuality = 1.0;
  let currentBlob: Blob | null = null;
  let iterations = 0;

  const getBlobWithQuality = (q: number): Promise<Blob | null> => {
    return new Promise(resolve => {
      canvas.toBlob(blob => resolve(blob), outputFormat, q);
    });
  };
  
  // Attempt initial compression
  currentBlob = await getBlobWithQuality(quality);
  if (!currentBlob) return null;

  // If initial compression is already smaller and good enough, or if target is very small
  if (currentBlob.size <= targetBytes && currentBlob.size > targetBytes * (1 - SIZE_TOLERANCE_PERCENT * 2)) {
     return { blob: currentBlob, quality };
  }
  if (currentBlob.size <= targetBytes && targetBytes < 50 * 1024) { // For very small targets, first attempt might be best
    return { blob: currentBlob, quality };
  }


  // Binary search for optimal quality
  while (iterations < MAX_ITERATIONS) {
    iterations++;
    currentBlob = await getBlobWithQuality(quality);

    if (!currentBlob) break; 

    const currentSize = currentBlob.size;
    const withinLowerBound = currentSize >= targetBytes * (1 - SIZE_TOLERANCE_PERCENT);
    const withinUpperBound = currentSize <= targetBytes * (1 + SIZE_TOLERANCE_PERCENT);
    
    if (withinLowerBound && withinUpperBound) { // Within tolerance
      break;
    }
    
    if (currentSize > targetBytes) {
      maxQuality = quality;
    } else {
      minQuality = quality;
    }

    const newQuality = (minQuality + maxQuality) / 2;
    if (Math.abs(newQuality - quality) < MIN_QUALITY_STEP || newQuality >=1 || newQuality <=0 ) {
        // If quality step is too small, or we hit bounds, break
        // Try to return the blob that is under or closest to target if over
        if (currentSize > targetBytes) { // current is over target
            const lowerQualityBlob = await getBlobWithQuality(quality - MIN_QUALITY_STEP > 0 ? quality - MIN_QUALITY_STEP : 0.01);
            if(lowerQualityBlob && lowerQualityBlob.size < currentSize) currentBlob = lowerQualityBlob;
        }
        break;
    }
    quality = newQuality;
  }
  
  // If after iterations, the size is still too large, try one last aggressive compression
  if (currentBlob && currentBlob.size > targetBytes * (1 + SIZE_TOLERANCE_PERCENT)) {
    const aggressiveQuality = Math.max(0.05, quality * 0.5); // Significantly reduce quality
    const lastAttemptBlob = await getBlobWithQuality(aggressiveQuality);
    if (lastAttemptBlob && lastAttemptBlob.size < currentBlob.size) {
      currentBlob = lastAttemptBlob;
      quality = aggressiveQuality;
    }
  }

  return currentBlob ? { blob: currentBlob, quality } : null;
}


/**
 * Formats bytes into a human-readable string (KB, MB).
 * @param bytes The number of bytes.
 * @param decimals The number of decimal places.
 * @returns A formatted string representing the file size.
 */
export function formatBytes(bytes: number, decimals = 2): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}
