import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import Script from 'next/script';
import './globals.css';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: {
    default: 'Krita Compress - Compress Images to KB/MB',
    template: '%s | Krita Compress',
  },
  description: 'Optimize your images with Krita Compress. Easily compress JPEGs and PNGs to a specific target file size in KB or MB, right in your browser. Fast, private, and free.',
  keywords: ['image compressor', 'kb compressor', 'mb compressor', 'optimize images', 'reduce image size', 'jpeg compression', 'png compression', 'krita compress'],
  robots: 'index, follow',
  openGraph: {
    title: 'Krita Compress - Compress Images to KB/MB',
    description: 'Optimize images to your desired file size (KB/MB) directly in your browser.',
    type: 'website',
    locale: 'en_US',
    url: 'https://kritacompress.app', // Replace with your actual domain
    siteName: 'Krita Compress',
    // images: [ // Add a preview image URL later
    //   {
    //     url: 'https://kritacompress.app/og-image.png',
    //     width: 1200,
    //     height: 630,
    //     alt: 'Krita Compress Image Compressor',
    //   },
    // ],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* 
          Google AdSense Integration:
          1. Replace 'ca-pub-YOUR_ADSENSE_PUBLISHER_ID' with your actual AdSense Publisher ID.
          2. Uncomment the <Script> tag below to enable AdSense.
          Ensure you comply with AdSense policies.
        */}
        {/*
        <Script
          async
          src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-YOUR_ADSENSE_PUBLISHER_ID`}
          crossOrigin="anonymous"
          strategy="afterInteractive"
        />
        */}
      </head>
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased flex flex-col min-h-screen`}>
        <Header />
        <main className="flex-grow container mx-auto px-4 py-8">
          {children}
        </main>
        <Footer />
        <Toaster />
      </body>
    </html>
  );
}
