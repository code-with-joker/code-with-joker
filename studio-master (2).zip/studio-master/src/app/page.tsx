import { ImageCompressorTool } from '@/components/impresso/ImageCompressorTool';
import { AdPlaceholder } from '@/components/impresso/AdPlaceholder';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Krita Compress - Online Image Compressor (KB/MB)',
  description: 'Compress JPEG/PNG images to a specific size in KB or MB. Fast, free, and secure client-side image optimization with Krita Compress.',
};

export default function HomePage() {
  return (
    <div className="w-full">
      <section className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
          Krita Compress Image Compressor
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Easily reduce your image file sizes to your desired KB or MB target. 
          All processing is done directly in your browser for maximum privacy.
        </p>
      </section>

      <AdPlaceholder adSlotId="YOUR_ADSENSE_AD_SLOT_ID_HOMEPAGE_TOP" className="mb-8" />

      <ImageCompressorTool />

      <AdPlaceholder adSlotId="YOUR_ADSENSE_AD_SLOT_ID_HOMEPAGE_BOTTOM" className="mt-12" />

      <section className="mt-16 text-center">
        <h2 className="text-2xl font-semibold mb-4">Why Choose Krita Compress?</h2>
        <div className="grid md:grid-cols-3 gap-8 text-left">
          <div className="p-6 bg-card rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-primary mb-2">Privacy First</h3>
            <p className="text-sm text-muted-foreground">Images are processed locally in your browser. Nothing is uploaded to our servers, ensuring your data remains private.</p>
          </div>
          <div className="p-6 bg-card rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-primary mb-2">Target Size Compression</h3>
            <p className="text-sm text-muted-foreground">Specify your desired file size in KB or MB, and Krita Compress will optimize your image to meet that target.</p>
          </div>
          <div className="p-6 bg-card rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-primary mb-2">Free & Easy to Use</h3>
            <p className="text-sm text-muted-foreground">A simple, intuitive interface makes image compression accessible to everyone, completely free of charge.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
