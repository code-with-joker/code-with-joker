import type { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export const metadata: Metadata = {
  title: 'Privacy Policy',
  description: 'Privacy Policy for Krita Compress - Online Image Compressor. Learn how we handle your data.',
};

export default function PrivacyPolicyPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-primary">Privacy Policy</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 text-muted-foreground">
          <p className="text-sm">Last updated: {new Date().toLocaleDateString()}</p>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">1. Introduction</h2>
            <p>Welcome to Krita Compress (&quot;we&quot;, &quot;us&quot;, or &quot;our&quot;). We are committed to protecting your privacy. This Privacy Policy explains how we handle information when you use our image compression tool (the &quot;Service&quot;).</p>
            <p>Our core principle regarding your images and data is simple: <strong>All image processing is done locally in your browser. Your images are never uploaded to our servers.</strong></p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">2. Information We Do Not Collect</h2>
            <p>Since all image processing occurs on your device (client-side), we do not collect, store, or have access to:</p>
            <ul className="list-disc list-inside ml-4 space-y-1">
              <li>The images you upload for compression.</li>
              <li>The compressed images you download.</li>
              <li>Any personal data embedded within your images (e.g., EXIF data that is not stripped by your browser before processing).</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">3. Information We May Collect (Non-Personal)</h2>
            <p>We may collect anonymous usage data to improve our Service. This data is aggregated and does not personally identify you. This may include:</p>
            <ul className="list-disc list-inside ml-4 space-y-1">
              <li>Browser type and version.</li>
              <li>Operating system.</li>
              <li>Date and time of access.</li>
              <li>Features used within the Service (e.g., compression settings chosen, errors encountered).</li>
              <li>Referring URLs (if you came to our site from another website).</li>
            </ul>
            <p>This information is collected through standard web analytics tools and helps us understand how users interact with Krita Compress so we can enhance its functionality and user experience.</p>
          </section>
          
          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">4. Cookies and Tracking Technologies</h2>
             <p>We may use cookies or similar tracking technologies for purposes such as:
            </p>
            <ul className="list-disc list-inside ml-4 space-y-1">
                <li>Remembering your preferences (e.g., theme settings if applicable).</li>
                <li>Analytics to understand service usage.</li>
                <li>Serving advertisements through third-party networks like Google AdSense.</li>
            </ul>
            <p>Google AdSense may use cookies (like the DoubleClick DART cookie) to serve ads based on your visit to our site and other sites on the Internet. You may opt out of the use of the DART cookie by visiting the Google Ad and Content Network privacy policy. Your browser settings can also be configured to manage or block cookies.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">5. Third-Party Services (Advertising)</h2>
            <p>Krita Compress may display advertisements, potentially through third-party ad networks like Google AdSense. These ad networks may use cookies and web beacons to collect non-personal information about your visits to this and other websites to provide advertisements about goods and services of interest to you.</p>
            <p>We do not provide any personal information to these third-party advertisers. Please consult their respective privacy policies for more information on their data collection practices.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">6. Security</h2>
            <p>While your images are processed client-side, we take reasonable measures to protect any anonymous data we collect. However, no internet transmission is 100% secure.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">7. Children's Privacy</h2>
            <p>Our Service is not intended for children under the age of 13. We do not knowingly collect personal information from children under 13.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">8. Changes to This Privacy Policy</h2>
            <p>We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground mb-2">9. Contact Us</h2>
            <p>If you have any questions about this Privacy Policy, please contact us through the information provided on our Contact Us page.</p>
          </section>
        </CardContent>
      </Card>
    </div>
  );
}
