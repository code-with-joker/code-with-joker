import type { Metadata } from 'next';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Mail, MessageSquare, User } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Contact Us',
  description: 'Get in touch with the Krita Compress team. We value your feedback and inquiries.',
};

// Placeholder for a server action or API call
async function submitContactForm(formData: FormData) {
  "use server";
  // In a real app, you would process the form data here (e.g., send an email, save to DB)
  // For this example, we'll just log it and return a success message.
  console.log("Form submitted:");
  console.log("Name:", formData.get("name"));
  console.log("Email:", formData.get("email"));
  console.log("Message:", formData.get("message"));
  // This is where you would interact with a backend or email service.
  // Example: await sendEmail({ name, email, message });
  return { success: true, message: "Thank you for your message! We'll get back to you soon." };
}


export default function ContactUsPage() {
  // State for form submission status would be handled by a client component wrapping the form
  // For simplicity with Server Actions, we'll keep this basic.

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <Card className="shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-primary">Contact Us</CardTitle>
          <CardDescription className="text-lg">We&apos;d love to hear from you! Send us your questions, feedback, or suggestions.</CardDescription>
        </CardHeader>
        <CardContent>
          {/* This form is a placeholder. For actual submission, you'd need client-side handling for state (loading, success, error) + server action or API endpoint */}
          <form action={submitContactForm} className="space-y-6">
            <div>
              <Label htmlFor="name" className="flex items-center mb-1">
                <User className="w-4 h-4 mr-2 text-muted-foreground" /> Your Name
              </Label>
              <Input type="text" id="name" name="name" placeholder="John Doe" required />
            </div>
            <div>
              <Label htmlFor="email" className="flex items-center mb-1">
                <Mail className="w-4 h-4 mr-2 text-muted-foreground" /> Your Email
              </Label>
              <Input type="email" id="email" name="email" placeholder="you@example.com" required />
            </div>
            <div>
              <Label htmlFor="message" className="flex items-center mb-1">
                <MessageSquare className="w-4 h-4 mr-2 text-muted-foreground" /> Your Message
              </Label>
              <Textarea id="message" name="message" rows={5} placeholder="How can we help you?" required />
            </div>
            <div className="text-center">
              <Button type="submit" className="w-full md:w-auto px-8">
                Send Message
              </Button>
            </div>
          </form>
          <p className="text-center text-sm text-muted-foreground mt-8">
            Alternatively, you can reach us at <a href="mailto:support@kritacompress.app" className="text-primary hover:underline">support@kritacompress.app</a> (placeholder email).
          </p>
           <p className="text-center text-xs text-muted-foreground mt-2">
            Note: Form submission is a placeholder and will log to server console. For real functionality, integrate with an email service or backend.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
