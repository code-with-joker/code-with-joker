'use client';

import { useState, ChangeEvent, useEffect, useRef } from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { UploadCloud, Image as ImageIcon, Download, AlertCircle, CheckCircle2, Settings2, Info } from 'lucide-react';
import { compressImageToTargetSize, formatBytes, TargetUnit } from '@/lib/image-utils';
import { useToast } from "@/hooks/use-toast";

export function ImageCompressorTool() {
  const [originalImage, setOriginalImage] = useState<File | null>(null);
  const [originalImageURL, setOriginalImageURL] = useState<string | null>(null);
  const [originalSize, setOriginalSize] = useState<number | null>(null);

  const [compressedImageURL, setCompressedImageURL] = useState<string | null>(null);
  const [compressedBlob, setCompressedBlob] = useState<Blob | null>(null);
  const [compressedSize, setCompressedSize] = useState<number | null>(null);
  const [compressionQuality, setCompressionQuality] = useState<number | null>(null);

  const [targetSizeInput, setTargetSizeInput] = useState<string>('500');
  const [targetUnit, setTargetUnit] = useState<TargetUnit>('KB');
  
  const [isCompressing, setIsCompressing] = useState<boolean>(false);
  const [compressionProgress, setCompressionProgress] = useState<number>(0); // For visual feedback if needed
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Clean up blob URLs when component unmounts or image changes
    return () => {
      if (originalImageURL) URL.revokeObjectURL(originalImageURL);
      if (compressedImageURL) URL.revokeObjectURL(compressedImageURL);
    };
  }, [originalImageURL, compressedImageURL]);

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
        setError('Invalid file type. Please upload a JPEG, PNG, or WEBP image.');
        toast({ variant: "destructive", title: "Invalid File Type", description: "Please upload a JPEG, PNG, or WEBP image." });
        return;
      }
      if (file.size > 20 * 1024 * 1024) { // 20MB limit
        setError('File is too large. Maximum size is 20MB.');
        toast({ variant: "destructive", title: "File Too Large", description: "Maximum upload size is 20MB." });
        return;
      }

      setOriginalImage(file);
      setOriginalSize(file.size);
      if (originalImageURL) URL.revokeObjectURL(originalImageURL); // Revoke old URL
      setOriginalImageURL(URL.createObjectURL(file));
      
      // Reset compressed state
      if (compressedImageURL) URL.revokeObjectURL(compressedImageURL);
      setCompressedImageURL(null);
      setCompressedBlob(null);
      setCompressedSize(null);
      setCompressionQuality(null);
      setError(null);
      setSuccessMessage(null);
    }
  };

  const handleCompressImage = async () => {
    if (!originalImage) {
      setError('Please upload an image first.');
      toast({ variant: "destructive", title: "No Image", description: "Please upload an image first." });
      return;
    }

    const targetSize = parseFloat(targetSizeInput);
    if (isNaN(targetSize) || targetSize <= 0) {
      setError('Please enter a valid target size.');
      toast({ variant: "destructive", title: "Invalid Target Size", description: "Please enter a valid positive number for the target size." });
      return;
    }

    setIsCompressing(true);
    setCompressionProgress(0); // Reset progress
    setError(null);
    setSuccessMessage(null);
    if (compressedImageURL) URL.revokeObjectURL(compressedImageURL);
    setCompressedImageURL(null);
    setCompressedBlob(null);
    setCompressedSize(null);
    setCompressionQuality(null);

    // Simulate progress for UI
    let progressInterval = setInterval(() => {
      setCompressionProgress(prev => (prev < 90 ? prev + 10 : prev));
    }, 100);

    try {
      const result = await compressImageToTargetSize(originalImage, targetSize, targetUnit);
      clearInterval(progressInterval);
      setCompressionProgress(100);

      if (result) {
        setCompressedBlob(result.blob);
        setCompressedImageURL(URL.createObjectURL(result.blob));
        setCompressedSize(result.blob.size);
        setCompressionQuality(result.quality);
        const successMsg = `Image compressed successfully to ${formatBytes(result.blob.size)}. (Quality: ${(result.quality * 100).toFixed(0)}%)`;
        setSuccessMessage(successMsg);
        toast({ title: "Compression Successful", description: successMsg });

        if (originalSize && result.blob.size > originalSize) {
             toast({ variant: "default", title: "Note", description: "Compressed size is larger than original. Original image might be already highly optimized or target size too high." });
        }

      } else {
        const failMsg = 'Failed to compress image. The target size might be too small for this image or an unexpected error occurred.';
        setError(failMsg);
        toast({ variant: "destructive", title: "Compression Failed", description: failMsg });
      }
    } catch (err) {
      clearInterval(progressInterval);
      setCompressionProgress(100); // Still finish progress bar
      console.error('Compression error:', err);
      const errorMsg = 'An unexpected error occurred during compression.';
      setError(errorMsg);
      toast({ variant: "destructive", title: "Error", description: errorMsg });
    } finally {
      setIsCompressing(false);
      setTimeout(() => setCompressionProgress(0), 1000); // Reset progress bar after a delay
    }
  };

  const handleDownloadCompressed = () => {
    if (!compressedBlob || !compressedImageURL) return;
    const link = document.createElement('a');
    link.href = compressedImageURL;
    const originalNameParts = originalImage?.name.split('.') ?? ['compressed_image', 'jpg'];
    const extension = compressedBlob.type.split('/')[1] || originalNameParts.pop() || 'jpg';
    const nameWithoutExtension = originalNameParts.join('.');
    link.download = `${nameWithoutExtension}_compressed.${extension}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({ title: "Download Started", description: `Downloading ${link.download}` });
  };
  
  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <Card className="w-full max-w-4xl mx-auto shadow-xl">
      <CardHeader>
        <CardTitle className="text-2xl flex items-center gap-2"><Settings2 className="text-primary" />Compression Settings</CardTitle>
        <CardDescription>Upload your image and set your desired compression target.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <Label htmlFor="image-upload" className="text-base">Upload Image</Label>
          <div 
            className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-border rounded-lg cursor-pointer bg-muted/50 hover:bg-muted transition-colors"
            onClick={triggerFileInput}
            onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files) handleFileChange({ target: { files: e.dataTransfer.files } } as any);}}
            onDragOver={(e) => e.preventDefault()}
          >
            <UploadCloud className="w-12 h-12 text-muted-foreground mb-2" />
            <p className="text-muted-foreground">
              <span className="font-semibold text-primary">Click to upload</span> or drag and drop
            </p>
            <p className="text-xs text-muted-foreground">JPEG, PNG, WEBP (Max 20MB)</p>
          </div>
          <Input 
            id="image-upload" 
            type="file" 
            className="hidden" 
            accept="image/jpeg,image/png,image/webp" 
            onChange={handleFileChange}
            ref={fileInputRef}
          />
           <div className="flex items-start p-3 rounded-md bg-accent/10 text-accent-foreground border border-accent/30 mt-2">
            <Info className="w-5 h-5 mr-2 shrink-0 mt-0.5 text-accent" />
            <p className="text-xs">
              <strong>Privacy Guaranteed:</strong> All image processing happens directly in your browser. Your files are never uploaded to any server.
            </p>
          </div>
        </div>

        {originalImage && (
          <div className="space-y-4 p-4 border border-border rounded-lg bg-background">
            <h3 className="text-lg font-semibold">Set Target Size</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
              <div className="space-y-1">
                <Label htmlFor="target-size">Target Size</Label>
                <Input 
                  id="target-size" 
                  type="number" 
                  value={targetSizeInput} 
                  onChange={(e) => setTargetSizeInput(e.target.value)} 
                  placeholder="e.g., 500"
                  disabled={isCompressing}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="target-unit">Unit</Label>
                <Select value={targetUnit} onValueChange={(value: string) => setTargetUnit(value as TargetUnit)} disabled={isCompressing}>
                  <SelectTrigger id="target-unit">
                    <SelectValue placeholder="Select unit" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="KB">KB (Kilobytes)</SelectItem>
                    <SelectItem value="MB">MB (Megabytes)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleCompressImage} disabled={isCompressing || !originalImage} className="w-full md:w-auto h-10">
                {isCompressing ? 'Compressing...' : 'Compress Image'}
              </Button>
            </div>
          </div>
        )}

        {isCompressing && (
          <div className="space-y-2">
            <Label>Compression Progress</Label>
            <Progress value={compressionProgress} className="w-full" />
            <p className="text-sm text-muted-foreground text-center">Optimizing your image, please wait...</p>
          </div>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        {successMessage && !error && (
           <Alert variant="default" className="bg-green-50 dark:bg-green-900/30 border-green-300 dark:border-green-700">
            <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
            <AlertTitle className="text-green-700 dark:text-green-300">Success</AlertTitle>
            <AlertDescription className="text-green-600 dark:text-green-400">{successMessage}</AlertDescription>
          </Alert>
        )}

        {(originalImageURL || compressedImageURL) && (
          <div className="grid md:grid-cols-2 gap-6 pt-6">
            {originalImageURL && originalSize !== null && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><ImageIcon /> Original Image</CardTitle>
                  <CardDescription>{formatBytes(originalSize)}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video relative w-full bg-muted rounded overflow-hidden">
                    <Image src={originalImageURL} alt="Original" layout="fill" objectFit="contain" data-ai-hint="abstract texture" />
                  </div>
                </CardContent>
              </Card>
            )}
            {compressedImageURL && compressedSize !== null && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><ImageIcon className="text-primary" /> Compressed Image</CardTitle>
                  <CardDescription>
                    {formatBytes(compressedSize)}
                    {originalSize && ` (${((1 - compressedSize / originalSize) * 100).toFixed(1)}% reduction)`}
                    {compressionQuality && ` (Q: ${(compressionQuality * 100).toFixed(0)}%)`}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="aspect-video relative w-full bg-muted rounded overflow-hidden">
                     <Image src={compressedImageURL} alt="Compressed" layout="fill" objectFit="contain" data-ai-hint="geometric pattern" />
                  </div>
                  <Button onClick={handleDownloadCompressed} className="w-full" variant="outline">
                    <Download className="mr-2 h-4 w-4" /> Download Compressed Image
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
