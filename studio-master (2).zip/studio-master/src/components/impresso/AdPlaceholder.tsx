'use client';

import { useEffect } from 'react';
import { cn } from '@/lib/utils';

interface AdPlaceholderProps {
  adSlotId: string;
  className?: string;
  isResponsive?: boolean;
}

export function AdPlaceholder({ adSlotId, className, isResponsive = true }: AdPlaceholderProps) {
  useEffect(() => {
    // This is a placeholder for AdSense initialization logic.
    // The main AdSense script should be in RootLayout.
    // This attempts to push an ad to an existing AdSense queue.
    try {
      ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
    } catch (e) {
      console.error("AdSense error:", e);
    }
  }, [adSlotId]);

  return (
    <div className={cn("my-4 flex min-h-[100px] items-center justify-center border-2 border-dashed border-muted-foreground/30 bg-muted/50 p-4 text-center text-muted-foreground shadow-inner rounded-md", className)}>
      <div>
        <p className="font-semibold">Advertisement Area</p>
        <p className="text-xs mt-1">
          This is a placeholder for an ad unit.
        </p>
        <div className="mt-2 p-2 bg-background border border-border rounded text-xs">
          <p>To activate this ad slot:</p>
          <ol className="list-decimal list-inside text-left">
            <li>Ensure the main AdSense script is in `src/app/layout.tsx` (uncommented and with your publisher ID).</li>
            <li>Replace `YOUR_ADSENSE_AD_SLOT_ID...` in the parent component with your actual Ad Unit ID for this slot.</li>
            <li>Insert the following AdSense code snippet where this component is used, or adapt this component:</li>
          </ol>
          <pre className="mt-1 p-2 bg-muted rounded-sm text-xs overflow-auto">
            <code>
{`<!-- Ad Unit: ${adSlotId} -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-YOUR_ADSENSE_PUBLISHER_ID" 
     data-ad-slot="${adSlotId}"
     data-ad-format="auto"${isResponsive ? `
     data-full-width-responsive="true"` : ''}>
</ins>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({});
</script>`}
            </code>
          </pre>
           <p className="mt-1 text-red-500">This placeholder is for development visibility. In production, replace it with actual AdSense code.</p>
        </div>
      </div>
    </div>
  );
}
