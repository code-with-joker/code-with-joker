import Link from 'next/link';

export function Footer() {
  const legalPages = [
    { href: '/privacy-policy', label: 'Privacy Policy' },
    { href: '/terms-conditions', label: 'Terms & Conditions' },
    { href: '/about-us', label: 'About Us' },
    { href: '/contact-us', label: 'Contact Us' },
  ];

  return (
    <footer className="bg-muted text-muted-foreground mt-auto">
      <div className="container mx-auto px-4 py-8">
        <nav className="flex flex-wrap justify-center gap-x-6 gap-y-2 mb-6">
          {legalPages.map((page) => (
            <Link
              key={page.href}
              href={page.href}
              className="text-sm hover:text-primary transition-colors"
            >
              {page.label}
            </Link>
          ))}
        </nav>
        <div className="text-center text-sm">
          <p>Images are processed in your browser and never uploaded to our servers.</p>
          <p className="mt-2">&copy; {new Date().getFullYear()} Krita Compress. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
