import Link from 'next/link';

// Custom Krita Compress SVG Logo
const KritaCompressLogo = () => (
  <svg width="32" height="32" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 15C20 12.2386 22.2386 10 25 10H60.3571L75 24.6429V85C75 87.7614 72.7614 90 70 90H25C22.2386 90 20 87.7614 20 85V15Z" stroke="#1E293B" strokeWidth="5" strokeLinejoin="round"/>
    <path d="M59 10V26H75" stroke="#1E293B" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="40" cy="40" r="8" fill="#FDBA74" stroke="#1E293B" strokeWidth="3"/>
    <path d="M30 70L45 55L60 70H30Z" fill="#34D399" stroke="#1E293B" strokeWidth="3" strokeLinejoin="round"/>
    <path d="M50 65L50 80M45 75H55" stroke="#3B82F6" strokeWidth="5" strokeLinecap="round"/>
  </svg>
);

export function Header() {
  return (
    <header className="bg-background shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="flex items-center gap-2 text-2xl font-bold text-primary hover:text-primary/80 transition-colors">
          <KritaCompressLogo />
          <span>Krita Compress</span>
        </Link>
        <nav className="space-x-4">
          {/* Add navigation links here if needed in the future, e.g., for a blog or FAQ */}
          {/* For now, primary navigation is via footer for legal pages */}
        </nav>
      </div>
    </header>
  );
}
